function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6TOMUuIZr1U":
        Script1();
        break;
      case "6WSZL8uslNW":
        Script2();
        break;
      case "6Ih6F5rXfD9":
        Script3();
        break;
      case "6Jfmw3rs2rM":
        Script4();
        break;
      case "5nFi9FhOjhB":
        Script5();
        break;
      case "6WSnojpiKq2":
        Script6();
        break;
      case "6mx8vl0FY2V":
        Script7();
        break;
      case "5wH5PXD4SF4":
        Script8();
        break;
      case "5vDKPrGzGNN":
        Script9();
        break;
      case "6Dic3JZ0T2z":
        Script10();
        break;
      case "5idQLpIzk8L":
        Script11();
        break;
      case "6GeTt8cBWKV":
        Script12();
        break;
      case "6p1g44xLwZ9":
        Script13();
        break;
      case "69knk3eSYyl":
        Script14();
        break;
      case "6eafcbrKSGt":
        Script15();
        break;
      case "6nPhHpdmoc6":
        Script16();
        break;
      case "6o3TTV1JFPC":
        Script17();
        break;
      case "6KSsEREHjTP":
        Script18();
        break;
      case "5npsVUnLfiu":
        Script19();
        break;
      case "6mvzayA73ex":
        Script20();
        break;
      case "6MYsr3Zkv7J":
        Script21();
        break;
      case "5Woo4Rd9BZ3":
        Script22();
        break;
      case "6jXTDrcRshw":
        Script23();
        break;
      case "5qH0fcdNl5Q":
        Script24();
        break;
      case "6NLbhx8WQ9Z":
        Script25();
        break;
      case "64PGuN9bApB":
        Script26();
        break;
  }
}

window.InitExecuteScripts = function()
{
var player = GetPlayer();
var object = player.object;
var once = player.once;
var addToTimeline = player.addToTimeline;
var setVar = player.SetVar;
var getVar = player.GetVar;
var update = player.update;
var pointerX = player.pointerX;
var pointerY = player.pointerY;
var showPointer = player.showPointer;
var hidePointer = player.hidePointer;
var slideWidth = player.slideWidth;
var slideHeight = player.slideHeight;
window.Script1 = function()
{
  const target = object('68khX0BC15q');
const duration = 250;
const easing = 'ease-in-out';
const id = '6bvEqE3OLnd';
const growAmount = 0.2;
player.addForTriggers(
id,
target.animate(
[ {scale: `${1 + growAmount}` } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script2 = function()
{
  const target = object('68khX0BC15q');
const duration = 250;
const easing = 'ease-in-out';
const id = '6bvEqE3OLnd_reverse';
const growAmount = 0;
player.addForTriggers(
id,
target.animate(
[ {scale: `${1 + growAmount}` } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script3 = function()
{
  const target = object('5nlUUo5bHbq');
const duration = 250;
const easing = 'ease-in-out';
const id = '6FPTktRv6Yn';
const growAmount = 0.2;
player.addForTriggers(
id,
target.animate(
[ {scale: `${1 + growAmount}` } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script4 = function()
{
  const target = object('5nlUUo5bHbq');
const duration = 250;
const easing = 'ease-in-out';
const id = '6FPTktRv6Yn_reverse';
const growAmount = 0;
player.addForTriggers(
id,
target.animate(
[ {scale: `${1 + growAmount}` } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script5 = function()
{
  const target = object('6M75rm21vJZ');
const duration = 250;
const easing = 'ease-in-out';
const id = '6RfhdKnCaG1';
const growAmount = 0.2;
player.addForTriggers(
id,
target.animate(
[ {scale: `${1 + growAmount}` } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script6 = function()
{
  const target = object('6M75rm21vJZ');
const duration = 250;
const easing = 'ease-in-out';
const id = '6RfhdKnCaG1_reverse';
const growAmount = 0;
player.addForTriggers(
id,
target.animate(
[ {scale: `${1 + growAmount}` } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script7 = function()
{
  const target = object('6EkqsRyUtXO');
const duration = 250;
const easing = 'ease-in-out';
const id = '5fwC6odx2Vx';
const growAmount = 0.2;
player.addForTriggers(
id,
target.animate(
[ {scale: `${1 + growAmount}` } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script8 = function()
{
  const target = object('6EkqsRyUtXO');
const duration = 250;
const easing = 'ease-in-out';
const id = '5fwC6odx2Vx_reverse';
const growAmount = 0;
player.addForTriggers(
id,
target.animate(
[ {scale: `${1 + growAmount}` } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script9 = function()
{
  const target = object('6CExCgCouk5');
const duration = 250;
const easing = 'ease-out';
const id = '6o2QScViz2q';
const growAmount = 0.2;
player.addForTriggers(
id,
target.animate(
[ {scale: `${1 + growAmount}` } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script10 = function()
{
  const target = object('6CExCgCouk5');
const duration = 250;
const easing = 'ease-out';
const id = '6o2QScViz2q_reverse';
const growAmount = 0;
player.addForTriggers(
id,
target.animate(
[ {scale: `${1 + growAmount}` } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script11 = function()
{
  const target = object('5cfwGBbT1Hz');
const duration = 250;
const easing = 'ease-in-out';
const id = '6hI054S2Wlk';
const growAmount = 0.2;
player.addForTriggers(
id,
target.animate(
[ {scale: `${1 + growAmount}` } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script12 = function()
{
  const target = object('5cfwGBbT1Hz');
const duration = 250;
const easing = 'ease-in-out';
const id = '6hI054S2Wlk_reverse';
const growAmount = 0;
player.addForTriggers(
id,
target.animate(
[ {scale: `${1 + growAmount}` } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script13 = function()
{
  const target = object('6eCoHs5eE5t');
const duration = 250;
const easing = 'ease-out';
const id = '6hAx0jDgMMr';
const growAmount = 0.2;
player.addForTriggers(
id,
target.animate(
[ {scale: `${1 + growAmount}` } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script14 = function()
{
  const target = object('6eCoHs5eE5t');
const duration = 250;
const easing = 'ease-out';
const id = '6hAx0jDgMMr_reverse';
const growAmount = 0;
player.addForTriggers(
id,
target.animate(
[ {scale: `${1 + growAmount}` } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script15 = function()
{
  const target = object('6qHz8I7873X');
const duration = 250;
const easing = 'ease-in-out';
const id = '6FPTktRv6Yn';
const growAmount = 0.2;
player.addForTriggers(
id,
target.animate(
[ {scale: `${1 + growAmount}` } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script16 = function()
{
  const target = object('6qHz8I7873X');
const duration = 250;
const easing = 'ease-in-out';
const id = '6FPTktRv6Yn_reverse';
const growAmount = 0;
player.addForTriggers(
id,
target.animate(
[ {scale: `${1 + growAmount}` } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script17 = function()
{
  const target = object('5W1PapemBwj');
const duration = 250;
const easing = 'ease-out';
const id = '6FEwxGLdYPA';
const growAmount = 0.2;
player.addForTriggers(
id,
target.animate(
[ {scale: `${1 + growAmount}` } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script18 = function()
{
  const target = object('5W1PapemBwj');
const duration = 250;
const easing = 'ease-out';
const id = '6FEwxGLdYPA_reverse';
const growAmount = 0;
player.addForTriggers(
id,
target.animate(
[ {scale: `${1 + growAmount}` } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script19 = function()
{
  const target = object('6e3pTl2dylm');
const duration = 250;
const easing = 'ease-out';
const id = '6gVZFDhjjcQ';
const growAmount = 0.2;
player.addForTriggers(
id,
target.animate(
[ {scale: `${1 + growAmount}` } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script20 = function()
{
  const target = object('6e3pTl2dylm');
const duration = 250;
const easing = 'ease-out';
const id = '6gVZFDhjjcQ_reverse';
const growAmount = 0;
player.addForTriggers(
id,
target.animate(
[ {scale: `${1 + growAmount}` } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script21 = function()
{
  const target = object('6HbQ6vtbTr6');
const duration = 250;
const easing = 'ease-out';
const id = '6asVmG8Fvu7';
const growAmount = 0.2;
player.addForTriggers(
id,
target.animate(
[ {scale: `${1 + growAmount}` } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script22 = function()
{
  const target = object('6HbQ6vtbTr6');
const duration = 250;
const easing = 'ease-out';
const id = '6asVmG8Fvu7_reverse';
const growAmount = 0;
player.addForTriggers(
id,
target.animate(
[ {scale: `${1 + growAmount}` } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script23 = function()
{
  const target = object('6ZcusmbXGUR');
const duration = 250;
const easing = 'ease-out';
const id = '6etV6B7LVyM';
const growAmount = 0.2;
player.addForTriggers(
id,
target.animate(
[ {scale: `${1 + growAmount}` } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script24 = function()
{
  const target = object('6ZcusmbXGUR');
const duration = 250;
const easing = 'ease-out';
const id = '6etV6B7LVyM_reverse';
const growAmount = 0;
player.addForTriggers(
id,
target.animate(
[ {scale: `${1 + growAmount}` } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

};
